
import { Avatar, Checkbox, Grid, Paper, TextField, FormControlLabel, Button, Typography, Link } from '@mui/material';
import { useState } from "react";


function App() {
  const [userName, setUserName] = useState('');
  const [passWord, setPassWord] = useState('');
  const handleSubmit = () => {
    console.log("userName: " + userName + " passWord : " + passWord)

  }
  const PaperStyled = { padding: 20, height: '70vh', width: 350, margin: "70px auto" }
  const avatarStyle = { backgroundcolor: 'green' }
  const btStyle = { margin: "20px 0px" }
  const textStyle = { margin: "15px 0px" }
  const linkStyle = { margin: "0px 10px", padding: 30 }
  const SignupStyle = { margin: "0px 30px" }

  return (
    <Grid >
      <Paper elevation={20} style={PaperStyled}>

        <Grid align='center'>
          <Avatar style={avatarStyle}>D</Avatar>
          <h2>Sign In</h2>
        </Grid>
        <TextField style={textStyle} label="Username" variant="outlined" placeholder='Enter username'
          id="userName" fullWidth required onChange={(e) => setUserName(e.target.value)} >
        </TextField>

        <TextField style={textStyle} type="Password"
          id="Password" label="Password" variant="outlined" placeholder='Enter username' fullWidth required onChange={(e) => setPassWord(e.target.value)} />
        <FormControlLabel control={<Checkbox defaultChecked />} label="Remember me" />
        <Button type='submit' color='primary' style={btStyle} fullWidth variant="contained" onClick={handleSubmit}>Sign In</Button>
        <hr></hr>
        <Typography style={linkStyle} >

          <Link href='#'> Forgot Password?</Link>
          <Link href='/signup' style={SignupStyle} >Sign Up</Link>
        </Typography>

      </Paper>
    </Grid>

  )

}

export default App;
