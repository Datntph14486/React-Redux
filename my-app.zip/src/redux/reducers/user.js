import {
    CREATE_TUTORIAL,
    RETRIEVE_TUTORIALS,
    UPDATE_TUTORIAL,
    DELETE_TUTORIAL,
    DELETE_ALL_TUTORIALS,
} from "../actions/types";
const initialState = [];
function userReducer(user = initialState, action) {
    const { type, payload } = action;
    switch (type) {
        case CREATE_TUTORIAL:
            return [...user, payload];
        case RETRIEVE_TUTORIALS:
            return payload;
        case UPDATE_TUTORIAL:
            return user.map(
                (user) => {
                    if (user.id === payload) {
                        return {
                            ...user,
                            ...payload,
                        }
                    } else {
                        return user;
                    }
                }
            );
        case DELETE_TUTORIAL:
            return user.filter(
                ({ id }) => id !== payload.id
            );
        case DELETE_ALL_TUTORIALS:
            return [];
        default:
            return user;
    }
};
export default userReducer;
