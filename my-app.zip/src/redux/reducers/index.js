import { combineReducers } from '@reduxjs/toolkit';

import user from "./user";

export default combineReducers({
    user,
});